package seleniumcode;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import constants.AppConstants;

public class DragAndDrop {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		Actions action = new Actions(driver);
		driver.get("http://jqueryui.com/droppable/");
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.cssSelector(".demo-frame")));
		WebElement sourceLocator = driver.findElement(By.cssSelector("#draggable"));
		WebElement targetLocator = driver.findElement(By.cssSelector("#droppable"));
		Thread.sleep(3000);
		action.dragAndDrop(sourceLocator, targetLocator).build().perform();
        Thread.sleep(3000);
        driver.close();
	}

}
