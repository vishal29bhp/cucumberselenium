
package gluecode;

import java.util.concurrent.TimeUnit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cucumber.listener.Reporter;

import constants.AppConstants;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementlocators.ElementLocators;

public class LoginTest {

	public static WebDriver driver;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		driver = new ChromeDriver();
	}

	@Given("^loginPage$") public void loginpage() throws Throwable {
  
  Reporter.addStepLog("Chrome Driver Initialized");
  driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); // This is  the default timeout 
  driver.get(AppConstants.loginUrl);
  Reporter.addStepLog("Login URL hit Successfull");
  driver.manage().window().maximize();
  Reporter.addStepLog("Browser Window Maximized");
  Reporter.addScreenCaptureFromPath(
  "C:\\Users\\Vishal.Chawre\\Desktop\\SoftwareTestingMaterial.png"); }

	@When("^user enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
		driver.findElement(By.id(ElementLocators.emailTextFieldLocator)).sendKeys(AppConstants.email);
		driver.findElement(By.id(ElementLocators.pwdTextFieldLocator)).sendKeys(AppConstants.pwd);
		Reporter.addStepLog("User Name Password Entered");
		String dataSiteKey = "6LdJtY8UAAAAADTgIWYnG_VKkfNqqB-w8CdQFL7Y";

		/*
		 * ImageTyperzAPI i = new ImageTyperzAPI("6CE9B6EA35D54FC19BB4B2E86F3533FA");
		 * HashMap<String, String> map = new HashMap<String, String>();
		 * map.put("page_url", AppConstants.loginUrl); map.put("sitekey", dataSiteKey);
		 * String recaptchaId = i.submit_recaptcha(map); while
		 * (i.in_progress(recaptchaId)) { Thread.sleep(10000); } String g_response_code
		 * = i.retrieve_captcha(recaptchaId); System.out.println(g_response_code);
		 */

		String g_response_code = "";
		HttpClient httpClient = HttpClientBuilder.create().build();
		try {
			HttpGet getRequest = new HttpGet(
					"https://2captcha.com/in.php?key=cb361253b0a5b012f9740d9e4dc34b8c&method=userrecaptcha&googlekey=6LdJtY8UAAAAADTgIWYnG_VKkfNqqB-w8CdQFL7Y&pageurl=https://phptravels.org/clientarea.php");
			HttpResponse httpResponse = httpClient.execute(getRequest);
			if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
				System.out.println("All Ok");
				HttpEntity entity = httpResponse.getEntity();
				if (entity != null) {
					String response = EntityUtils.toString(entity);
					System.out.println(response);
				}
			}
		} finally {

		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('g-recaptcha-response').innerHTML = '" + g_response_code + "';");
		driver.findElement(By.id(ElementLocators.loginButtonLocator)).click();
		Reporter.addStepLog("Login Button Clicked");
	}

	@Then("^validate login is successful$")
	public void validate_login_is_successful() throws Throwable {
		if (driver.findElement(By.linkText(ElementLocators.homeLinkLocator)) != null) {
			System.out.println("------Login is Successfull!!------");
			Reporter.addStepLog("Login is Successfull!!");
		}
	}

	@Then("^navigate to services page$")
	public void navigate_to_services_page() throws Throwable {

		driver.findElement(By.xpath(ElementLocators.servicesLinkLocator)).click();
		Reporter.addStepLog("Primary Service Bar Link Clicked");
		Thread.sleep(2000);
		driver.findElement(By.xpath(ElementLocators.myServiceLinkLocator)).click();
		Reporter.addStepLog("My Services Link Clicked");
		Thread.sleep(3000);
	}

	@Then("^user successfully logout$")
	public void user_successfully_logout() throws Throwable {
		driver.findElement(By.xpath("//*[@id='Secondary_Navbar-Account']/a")).click();
		Reporter.addStepLog("Secondary Services Bar Link Clicked");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='Secondary_Navbar-Account-Logout']/a")).click();
		Reporter.addStepLog("Logout Button Clicked");
		if (driver.getPageSource().contains(ElementLocators.logoutText)) {
			System.out.println("-----Logout is successful!!---------");
			Reporter.addStepLog("Logout is successful!!");
		}
		Reporter.addScreenCaptureFromPath(
				"C:\\Users\\Vishal.Chawre\\Desktop\\SelenuimWithJava\\SoftwareTestingMaterial.png");
		Thread.sleep(2000);
	}

	@After
	public void cleanUp() {
		System.out.println("-------Closing Browser----------");
		Reporter.addStepLog("Closing Browser");
		driver.close();
		driver.quit();
		System.out.println("--------Test Done!!-------------");
		Reporter.addStepLog("Test Done!!");
	}
}
