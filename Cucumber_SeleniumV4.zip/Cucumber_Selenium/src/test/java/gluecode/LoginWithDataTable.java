package gluecode;

import java.util.ArrayList;
import java.util.List;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pojo.User;

public class LoginWithDataTable {
	
	
	@Given("^loginPageWithDataTable$")
	public void loginPageWithDataTable() throws Throwable {
		Reporter.addStepLog("Login URL hit Successfull");
	}

	@When("^user enters following users credentials$")
	public void user_enters_following_users_credentials(DataTable dataTable) throws Throwable {
		Reporter.addStepLog("------Datatable with raw method----------");
		List<List<String>> credentials = dataTable.raw();
		for(List<String> entries :credentials) {
			for(String value:entries)
			Reporter.addStepLog(value);
		}
		// Datatable with Custom class 
		Reporter.addStepLog("----------Datatable with Custom class---------");
		List<User> users = dataTable.asList(User.class);
		for(User user: users) {
			Reporter.addStepLog(user.getUserName()+"--"+user.getPassword());
		}
		
	}

	@Then("^validate login$")
	public void validate_login() throws Throwable {
		Reporter.addStepLog("Login Successfull");
	}

	@Then("^navigate to services$")
	public void navigate_to_services() throws Throwable {
		Reporter.addStepLog("navigate_to_services_page Successfull");
	}

	@Then("^user logout$")
	public void user_logout() throws Throwable {
		Reporter.addStepLog("user_successfully_logout");
	}

}
