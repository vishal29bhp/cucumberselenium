package gluecode;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test {
	
	@Given("^Menu Page$")
	public void menu_Page() throws Throwable {
	    System.out.println("Menu Page");
	}

	@When("^I add \"([^\"]*)\" to the menu item with price (\\d+)$")
	public void i_add_to_the_menu_item_with_price(String arg1, int arg2) throws Throwable {
		System.out.println("Dosa with 50 Rs");
	}

	@Then("^item added to the menu$")
	public void item_added_to_the_menu() throws Throwable {
		System.out.println("Item Added");
	}

}
