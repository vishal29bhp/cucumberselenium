package seleniumcode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import constants.AppConstants;

public class AlertTest{

	public static void alertWindow() throws Exception {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://softwaretestingplace.blogspot.com/2017/03/javascript-alert-test-page.html");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//div[@id='content']/button")).click();
		Alert alert1 = driver.switchTo().alert();
		Thread.sleep(3000);
		String print = alert1.getText();
		System.out.println(print);
		alert1.accept();
		Thread.sleep(3000);
		//alert1.dismiss();
		driver.close();
	}

	public static void main(String[] args) throws Exception {
		alertWindow();
	}
}