package seleniumcode;

import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;
//Completely Automated Public Turing test to tell Computers and Humans Apart
public class CaptchaValidation {
	private static WebDriver driver;
	private static String baseUrl;

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		baseUrl = "https://www.in.ckgs.us/myaccount/";
		driver.get(baseUrl);
		WebElement passportNo = driver.findElement(By.cssSelector("input[name='currentPassportNo']"));
		passportNo.clear();
		passportNo.sendKeys("123456789");
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		// Or Use Scanner class for console input
		driver.findElement(By.id("recaptcha_response_field")).sendKeys(captchaVal);
		driver.close();

	}

}
