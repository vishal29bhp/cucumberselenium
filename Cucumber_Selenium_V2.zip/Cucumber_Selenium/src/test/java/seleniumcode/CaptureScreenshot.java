package seleniumcode;

import java.io.File;

import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;

public class CaptureScreenshot {

	public static void alertWindow() throws Exception {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.softwaretestingmaterial.com/capture-screenshot-using-selenium-webdriver");
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("C:\\Users\\e059884\\Desktop\\SelenuimWithJava\\SoftwareTestingMaterial.png"));
		driver.close();
		driver.quit();
	}

	public static void main(String[] args) throws Exception {
		alertWindow();
	}
}