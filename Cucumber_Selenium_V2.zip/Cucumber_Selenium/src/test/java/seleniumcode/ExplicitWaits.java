package seleniumcode;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import constants.AppConstants;

public class ExplicitWaits {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();

		driver.get("http://www.SoftwareTestingmaterial.com");

		driver.manage().window().maximize();

		WebDriverWait wait = new WebDriverWait(driver, 15);

		wait.until(ExpectedConditions.titleIs("Software Testing Material - A site for Software Testers"));

		driver.close();

	}
}