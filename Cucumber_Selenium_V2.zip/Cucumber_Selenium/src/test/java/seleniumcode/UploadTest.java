package seleniumcode;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;

public class UploadTest {
	public static void main(String[] args) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		// To open URL "http://softwaretestingmaterial.com"
		driver.get("http://softwaretestingplace.blogspot.com/2015/10/sample-web-page-to-test.html");
		driver.manage().window().maximize();
		// Locating 'browse' button
		WebElement browse = driver.findElement(By.id("uploadfile"));
		// pass the path of the file to be uploaded using Sendkeys method
		browse.sendKeys("C:\\Users\\e059884\\Desktop\\SelenuimWithJava\\TestNg Notes.txt");
		// 'close' method is used to close the browser window
		Thread.sleep(8000);
		driver.close();
	}
}